StackOverFlow Analysis
======================

Top 20 Tags 
------------
<canvas id="top20tags" width="800" height="400"></canvas>


Quickly growing technologies
-----------------------------
<canvas id="popularityChange" width="800" height="400"></canvas>
<script src="sfo.js"></script>